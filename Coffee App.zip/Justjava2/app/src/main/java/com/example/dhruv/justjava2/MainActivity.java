package com.example.dhruv.justjava2;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int num=2;
    boolean hasCheckedForCream=false;
    int count=0;
    boolean hasCheckedForChocolate=false;
    int count2=0;
    String name;
    int priceConstant=5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
    }
    public void submitOrder(View view)
    {
        priceConstant=5;
        String priceMessage=createOrderSummary(num,hasCheckedForCream,hasCheckedForChocolate,name);

        //displayMessage(priceMessage);
        Intent intent=new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL,"coffee3@gmail.com");
        intent.putExtra(Intent.EXTRA_SUBJECT,"Order Summary");
        intent.putExtra(Intent.EXTRA_TEXT,priceMessage);
        if(intent.resolveActivity(getPackageManager())!=null)
        {
            startActivity(intent);
        }

        // displayPrice(num*5);

    }
    public String createOrderSummary(int number,boolean hasCheckedForCream,boolean hasCheckedForChocolate,String name)
    {
        if(hasCheckedForCream==true)
        {
            priceConstant+=1;
        }
        if(hasCheckedForChocolate)
            priceConstant+=2;
        return "Name: "+name+"\nAdd whipped cream?"+hasCheckedForCream+"\nAdd chocolate?"+hasCheckedForChocolate+"\nQunatity: "+number + "\nTotal: "+ num*priceConstant +"\n"+getString(R.string.thank_you) ;
    }

    private void display(int number)
    {
        TextView quantityTextView=(TextView)findViewById(R.id.quantity_text_view);
        quantityTextView.setText("" + number);
    }
    //    private void displayPrice(int number)
//    {
//        TextView priceTextView=(TextView)findViewById(R.id.order_summary_text_view);
//        priceTextView.setText(NumberFormat.getCurrencyInstance().format(number));
//    }
    public void increment(View view)
    {
        num=num+1;
        display(num);
    }
    public void decrement(View view)
    {

        num=num-1;
        if(num<=0) {
            num = 0;
            Context context = getApplicationContext();
            CharSequence text = "Cup of coffees cant be less than 1";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        display(num);
    }
    private void displayMessage(String message)
    {
        TextView orderSummaryTextView=(TextView) findViewById(R.id.order_summary_text_view);
        orderSummaryTextView.setText(message);
    }
    public void whetherChecked(View view)
    {

        count++;
        if(count%2!=0)
        hasCheckedForCream=true;
        else
            hasCheckedForCream=false;

    }
    public void isChecked(View view)
    {
        count2++;
        if(count2%2!=0)
            hasCheckedForChocolate=true;
        else
            hasCheckedForChocolate=false;
    }
    public void name(View view)
    {
        EditText userName=(EditText) findViewById(R.id.name_edit_text);
        Editable editable =userName.getEditableText();
        name =editable.toString();
        //OR
        // EditText userName=(EditText)findViewById(R.id.name_edit_text);
        //String name=userName.getText().toString();



    }
}
